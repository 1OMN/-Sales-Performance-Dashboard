# 📊 Sales Performance Dashboard (Power BI Project)

## 🧠 Project Overview
This project showcases a simulated sales performance dashboard built with Power BI, based on synthetic data from a fictional company. The goal is to demonstrate key Data Analyst skills in transforming, visualizing, and interpreting data to generate actionable business insights.

## 🔍 Objectives
- Monitor regional and product-based sales performance
- Analyze profit and revenue metrics
- Identify patterns over time using trend analysis
- Present insights via a clean and professional dashboard

## 📊 Dashboard Highlights
- **KPI Cards**: Total Revenue, Profit, and Units Sold
- **Bar Chart**: Revenue by Region
- **Line Chart**: Units Sold over Time
- **Pie Chart**: Product-based Sales Distribution with Percentages
- **Slicers**: Product, Region, and Date Filters

## 📈 Key Insights
- **Smartphones** generated the highest revenue (₺443,800), outperforming Laptops by over ₺30K.
- **North Region** contributed the largest share (35%) of total revenue.
- **Sales peaked in Q4**, indicating a seasonal or promotional influence.

## 💾 Files
- `/data/sales_data_onur_analyst_project.xlsx` – Source Excel dataset
- `/reports/Sales_Performance_Dashboard.pdf` – Dashboard PDF export
- `/insights/summary.txt` – Written business insights and recommendations

## 👨‍💼 Analyst
**Onur Mert Nemiş**  
📍 Hattersheim am Main, Germany  
🔗 [LinkedIn](https://linkedin.com/in/onurmertnemis)  
📧 o.mertnemis@gmail.com

---
